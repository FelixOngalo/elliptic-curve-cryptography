# Elliptic Curve Cryptography: Theory, Proof and Implementation

**Question:** *(fill in)* How do points on a curve give two strangers a shared secret, and what exactly protects it?

**Key findings:** *(fill in after running: group axioms and Lagrange/Hasse checks, ECDH failures, how BSGS cost scales with key size)*

**Tools:** R (base plus dplyr/tibble), Quarto report with proofs in LaTeX. No cryptography packages: the group law, point counting, scalar multiplication, ECDH and the discrete-log attack are all written from scratch.

## Why this project exists

Fifth in the pure-math series for an MSc Pure Mathematics portfolio: abstract algebra and algebraic geometry meeting cryptography. The report is explicit about what is **proved** and what is **cited**.

## Reproduce

1. `install.packages("tidyverse")` (needed to render the report)
2. Run `R/01_verify_theory.R` (about a minute)
3. Render `reports/report.qmd`

## Results covered

| Result | Status in this report |
|---|---|
| Group law formulas; closure | Proved (Vieta argument) |
| Associativity | Cited (Silverman, Washington); checked exhaustively on a small curve |
| Lagrange; prime-order subgroups | Proved; checked on several curves |
| Hasse's bound | Proof sketched and cited; checked on every curve over 21 primes |
| ECDH correctness | Proved (relies on associativity) |
| Baby-step giant-step | Proved; cost scaling measured across 4 curve sizes |

## Project structure

```
R/ecc_functions.R        group law, double-and-add, point counting, point orders,
                         prime-order curve search, baby-step giant-step
R/01_verify_theory.R     axioms, Lagrange, Hasse, ECDH, discrete-log scaling and attack
reports/report.qmd       theory, proofs, plots, interpretation
```

## Limitations

- Toy sizes (p < 1.1e6); real curves need big integers.
- Not constant-time, no point validation, no authentication: never use for real secrets.
- Associativity and Hasse's theorem are cited, not proved.
- *(add your own)*
