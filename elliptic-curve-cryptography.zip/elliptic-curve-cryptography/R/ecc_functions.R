# Elliptic curves over a prime field F_p, from scratch.
#
# A curve is y^2 = x^3 + a x + b (mod p), p a prime > 3, with
# 4a^3 + 27b^2 != 0 (mod p) so the curve has no cusp or self-crossing.
# Its points, plus a "point at infinity" O, form an abelian group.
#
# SCALE NOTE: R doubles are exact for integers below 2^53 (~9.0e15), and
# every intermediate product here is below p^2 (or 3p^2), so p must stay
# below ~3e7. That is ample to verify every theorem on small curves, but
# real curves (secp256k1, Curve25519) have ~256-bit p and need
# big-integer arithmetic (e.g. the `gmp` package). NOTE ON OPERATOR
# PRECEDENCE: in R, %% binds tighter than *, so every modular reduction
# below is fully parenthesized on purpose.

INF <- c(NA_real_, NA_real_)          # the point at infinity O (group identity)
is_inf <- function(P) is.na(P[1])

ec_equal <- function(P, Q) {
  if (is_inf(P) || is_inf(Q)) return(is_inf(P) && is_inf(Q))
  P[1] == Q[1] && P[2] == Q[2]
}

# ---- modular arithmetic ------------------------------------------------

gcd_ext <- function(a, b) {
  old_r <- a; r <- b; old_x <- 1; x <- 0
  while (r != 0) {
    q <- old_r %/% r
    tmp <- old_r - q * r; old_r <- r; r <- tmp
    tmp <- old_x - q * x; old_x <- x; x <- tmp
  }
  list(g = old_r, x = old_x)
}

mod_inverse <- function(a, n) {
  e <- gcd_ext(a %% n, n)
  if (e$g != 1) stop("no inverse: gcd(a, n) != 1")
  e$x %% n
}

mod_pow <- function(base, exp, n) {
  result <- 1; base <- base %% n
  while (exp > 0) {
    if (exp %% 2 == 1) result <- (result * base) %% n
    base <- (base * base) %% n
    exp <- exp %/% 2
  }
  result
}

is_prime <- function(n) {
  if (n < 4) return(n > 1)
  all(n %% 2:floor(sqrt(n)) != 0)
}

factorize <- function(n) {
  f <- c(); d <- 2
  while (d * d <= n) {
    while (n %% d == 0) { f <- c(f, d); n <- n / d }
    d <- d + 1
  }
  if (n > 1) f <- c(f, n)
  f
}

# ---- the curve ---------------------------------------------------------

is_nonsingular <- function(a, b, p) {
  a3 <- (((a * a) %% p) * a) %% p
  b2 <- (b * b) %% p
  ((4 * a3 + 27 * b2) %% p) != 0
}

make_curve <- function(a, b, p) {
  stopifnot(p > 3, is_prime(p), is_nonsingular(a %% p, b %% p, p))
  list(a = a %% p, b = b %% p, p = p)
}

ec_on_curve <- function(P, curve) {
  if (is_inf(P)) return(TRUE)
  p <- curve$p
  lhs <- (P[2] * P[2]) %% p
  rhs <- ((((P[1] * P[1]) %% p) * P[1]) + curve$a * P[1] + curve$b) %% p
  lhs == rhs
}

ec_neg <- function(P, curve) {
  if (is_inf(P)) return(INF)
  c(P[1], (curve$p - P[2]) %% curve$p)
}

#' The group law (chord-and-tangent). Derivation and proof of closure
#' are in reports/report.qmd. Cases:
#'   O + Q = Q;  P + (-P) = O;  otherwise slope lambda is the chord
#'   slope (P != Q) or the tangent slope (P = Q), and
#'   x3 = lambda^2 - x1 - x2,  y3 = lambda (x1 - x3) - y1.
ec_add <- function(P, Q, curve) {
  p <- curve$p
  if (is_inf(P)) return(Q)
  if (is_inf(Q)) return(P)
  x1 <- P[1]; y1 <- P[2]; x2 <- Q[1]; y2 <- Q[2]
  if (x1 == x2 && ((y1 + y2) %% p) == 0) return(INF)   # Q = -P (includes tangent at y = 0)
  if (x1 == x2) {
    lam <- ((((3 * ((x1 * x1) %% p)) + curve$a) %% p) * mod_inverse((2 * y1) %% p, p)) %% p
  } else {
    lam <- ((((y2 - y1) %% p)) * mod_inverse((x2 - x1) %% p, p)) %% p
  }
  x3 <- ((lam * lam) - x1 - x2) %% p
  y3 <- ((lam * (x1 - x3)) - y1) %% p
  c(x3, y3)
}

#' Scalar multiplication kP by double-and-add: O(log k) group operations
#' instead of k - 1 additions.
ec_mul <- function(k, P, curve) {
  if (k < 0) return(ec_mul(-k, ec_neg(P, curve), curve))
  result <- INF; addend <- P
  while (k > 0) {
    if (k %% 2 == 1) result <- ec_add(result, addend, curve)
    addend <- ec_add(addend, addend, curve)
    k <- k %/% 2
  }
  result
}

# ---- counting and enumerating points -----------------------------------

quadratic_residue_table <- function(p) {
  ys <- 0:(p - 1)
  tab <- logical(p)
  tab[((ys * ys) %% p) + 1] <- TRUE
  tab        # tab[v + 1] is TRUE iff v is a square mod p
}

#' #E(F_p) = 1 (for O) + number of affine solutions, computed in O(p):
#' for each x, y^2 = f(x) has 2 solutions if f(x) is a nonzero square,
#' 1 if f(x) = 0, and 0 otherwise.
ec_count_points <- function(a, b, p, is_qr = NULL) {
  if (is.null(is_qr)) is_qr <- quadratic_residue_table(p)
  xs <- 0:(p - 1)
  rhs <- ((((xs * xs) %% p) * xs) + a * xs + b) %% p
  1 + sum(ifelse(rhs == 0, 1, ifelse(is_qr[rhs + 1], 2, 0)))
}

#' All affine points as a 2-column matrix (x, y); O is not included.
ec_points <- function(curve) {
  p <- curve$p
  ys <- 0:(p - 1)
  by_square <- split(ys, factor((ys * ys) %% p, levels = 0:(p - 1)))
  xs <- 0:(p - 1)
  rhs <- ((((xs * xs) %% p) * xs) + curve$a * xs + curve$b) %% p
  rows <- lapply(xs, function(x) {
    y <- by_square[[rhs[x + 1] + 1]]
    if (length(y) > 0) cbind(x = x, y = y) else NULL
  })
  do.call(rbind, rows)
}

#' Order of P by naive repeated addition (small curves only).
ec_order_naive <- function(P, curve) {
  if (is_inf(P)) return(1)
  k <- 1; Q <- P
  while (!is_inf(Q)) { Q <- ec_add(Q, P, curve); k <- k + 1 }
  k
}

#' Order of P given the group order N: start at N and strip prime
#' factors q while (ord / q) P is still O. Valid because (Lagrange) the
#' order of P divides N.
ec_point_order <- function(P, curve, N) {
  ord <- N
  for (q in unique(factorize(N))) {
    while (ord %% q == 0 && is_inf(ec_mul(ord / q, P, curve))) ord <- ord / q
  }
  ord
}

# ---- toy "real-size" parameters, ECDH and the discrete log -------------

#' Find a curve over F_p (p = 3 mod 4, so square roots are one modular
#' exponentiation) whose group order is N = h * r with r prime and a
#' small cofactor h, plus a generator G of the prime-order-r subgroup.
#' Every non-identity point of a prime-order subgroup generates it
#' (Lagrange), which is why cryptographic curves are chosen this way.
find_prime_order_curve <- function(p, max_cofactor = 8, seed = 1) {
  stopifnot(p %% 4 == 3, is_prime(p))
  set.seed(seed)
  is_qr <- quadratic_residue_table(p)
  repeat {
    a <- sample(0:(p - 1), 1); b <- sample(0:(p - 1), 1)
    if (!is_nonsingular(a, b, p)) next
    N <- ec_count_points(a, b, p, is_qr)
    r <- max(factorize(N))
    if (r > 50 && N / r <= max_cofactor) break
  }
  curve <- make_curve(a, b, p); h <- N / r
  repeat {
    x <- sample(0:(p - 1), 1)
    rhs <- ((((x * x) %% p) * x) + a * x + b) %% p
    if (rhs == 0 || !is_qr[rhs + 1]) next
    y <- mod_pow(rhs, (p + 1) / 4, p)          # square root, valid since p = 3 (mod 4)
    G <- ec_mul(h, c(x, y), curve)
    if (!is_inf(G)) break
  }
  list(curve = curve, G = G, r = r, N = N, h = h)
}

point_key <- function(P) if (is_inf(P)) "inf" else paste(P[1], P[2])

#' Baby-step giant-step: solve Q = kG for k in [0, r) with about
#' 2 sqrt(r) group operations. Returns k and the number of steps used.
bsgs <- function(G, Q, r, curve) {
  m <- ceiling(sqrt(r))
  table <- new.env(hash = TRUE)
  P <- INF
  for (j in 0:(m - 1)) {                       # baby steps: store jG
    key <- point_key(P)
    if (is.null(table[[key]])) table[[key]] <- j
    P <- ec_add(P, G, curve)
  }
  step <- ec_neg(P, curve)                     # P is now mG; step = -mG
  gamma <- Q
  for (i in 0:(m - 1)) {                       # giant steps: Q - i m G
    j <- table[[point_key(gamma)]]
    if (!is.null(j)) return(list(k = (i * m + j) %% r, steps = m + i + 1))
    gamma <- ec_add(gamma, step, curve)
  }
  list(k = NA_real_, steps = 2 * m)
}
