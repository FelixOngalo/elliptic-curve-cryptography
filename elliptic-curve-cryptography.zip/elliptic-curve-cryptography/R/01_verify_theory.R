library(dplyr)
library(tibble)
source("R/ecc_functions.R")
set.seed(42)

# ---------------------------------------------------------------------
cat("=== 1. Group axioms, exhaustively, on y^2 = x^3 + x + 1 over F_23 ===\n")
curve <- make_curve(1, 1, 23)
affine <- ec_points(curve)
pts <- c(list(INF), lapply(seq_len(nrow(affine)), function(i) unname(affine[i, ])))
N <- length(pts)
cat("Group order #E:", N, "\n")

on_curve  <- all(vapply(pts, ec_on_curve, logical(1), curve = curve))
closed    <- TRUE; commutative <- TRUE; identity_ok <- TRUE; inverse_ok <- TRUE
for (P in pts) {
  identity_ok <- identity_ok && ec_equal(ec_add(P, INF, curve), P) && ec_equal(ec_add(INF, P, curve), P)
  inverse_ok  <- inverse_ok  && is_inf(ec_add(P, ec_neg(P, curve), curve))
  for (Q in pts) {
    S <- ec_add(P, Q, curve)
    closed <- closed && ec_on_curve(S, curve)
    commutative <- commutative && ec_equal(S, ec_add(Q, P, curve))
  }
}
assoc_violations <- 0
for (P in pts) for (Q in pts) {
  PQ <- ec_add(P, Q, curve)
  for (R in pts) {
    if (!ec_equal(ec_add(PQ, R, curve), ec_add(P, ec_add(Q, R, curve), curve))) assoc_violations <- assoc_violations + 1
  }
}
mul_ok <- all(vapply(2:15, function(k) {
  P <- pts[[2]]; Q <- INF
  for (i in seq_len(k)) Q <- ec_add(Q, P, curve)
  ec_equal(Q, ec_mul(k, P, curve))
}, logical(1)))
axioms <- tibble(
  property = c("All points satisfy the curve equation", "Closure (P + Q on curve)", "Identity (O)",
               "Inverses (P + (-P) = O)", "Commutativity", "Associativity violations (of N^3 triples)",
               "double-and-add agrees with repeated addition"),
  result = c(on_curve, closed, identity_ok, inverse_ok, commutative, assoc_violations, mul_ok))
print(axioms)

# ---------------------------------------------------------------------
cat("\n=== 2. Lagrange: every point order divides #E ===\n")
small <- list(c(23, 1, 1), c(97, 2, 3), c(101, 5, 7), c(251, 1, 6))
lagrange <- bind_rows(lapply(small, function(par) {
  cv <- make_curve(par[2], par[3], par[1])
  aff <- ec_points(cv)
  pts_c <- c(list(INF), lapply(seq_len(nrow(aff)), function(i) unname(aff[i, ])))
  N_c <- length(pts_c)
  ords_naive <- vapply(pts_c, ec_order_naive, numeric(1), curve = cv)
  ords_fast  <- vapply(pts_c, ec_point_order, numeric(1), curve = cv, N = N_c)
  tibble(p = par[1], a = par[2], b = par[3], group_order = N_c,
         violations = sum(N_c %% ords_naive != 0),
         fast_order_matches_naive = all(ords_naive == ords_fast),
         max_point_order = max(ords_naive), cyclic = max(ords_naive) == N_c)
}))
print(lagrange)

# ---------------------------------------------------------------------
cat("\n=== 3. Hasse's bound |#E - (p+1)| <= 2 sqrt(p), over EVERY curve ===\n")
primes <- c(11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97)
trace_ratio_97 <- NULL
hasse <- bind_rows(lapply(primes, function(p) {
  is_qr <- quadratic_residue_table(p)
  counts <- c(); ratios <- c()
  for (a in 0:(p - 1)) for (b in 0:(p - 1)) {
    if (!is_nonsingular(a, b, p)) next
    n <- ec_count_points(a, b, p, is_qr)
    counts <- c(counts, n); ratios <- c(ratios, (p + 1 - n) / (2 * sqrt(p)))
  }
  if (p == 97) trace_ratio_97 <<- ratios
  tibble(p = p, curves = length(counts), min_N = min(counts), max_N = max(counts),
         hasse_low = ceiling(p + 1 - 2 * sqrt(p)), hasse_high = floor(p + 1 + 2 * sqrt(p)),
         violations = sum(abs(p + 1 - counts) > 2 * sqrt(p)))
}))
print(hasse)

# ---------------------------------------------------------------------
cat("\n=== 4. ECDH and the discrete-log attack, across curve sizes ===\n")
sizes <- c(1019, 10007, 100003, 1000003)
scaling <- bind_rows(lapply(sizes, function(p) {
  prm <- find_prime_order_curve(p)
  cv <- prm$curve; G <- prm$G; r <- prm$r
  ks <- sample(2:(r - 1), 5)
  runs <- lapply(ks, function(k) {
    res <- bsgs(G, ec_mul(k, G, cv), r, cv)
    list(ok = identical(res$k, k) || isTRUE(res$k == k), steps = res$steps, brute = k)
  })
  tibble(p = p, group_order = prm$N, cofactor = prm$h, prime_order_r = r, key_bits = ceiling(log2(r)),
         bsgs_correct = all(vapply(runs, function(x) x$ok, logical(1))),
         mean_bsgs_steps = mean(vapply(runs, function(x) x$steps, numeric(1))),
         mean_bruteforce_steps = mean(vapply(runs, function(x) x$brute, numeric(1))),
         two_sqrt_r = 2 * sqrt(r))
}))
print(scaling)

cat("\n=== 5. ECDH key agreement + eavesdropper attack on the p = 100003 curve ===\n")
prm <- find_prime_order_curve(100003)
cv <- prm$curve; G <- prm$G; r <- prm$r
n_pairs <- 200
agree <- vapply(seq_len(n_pairs), function(i) {
  a <- sample(2:(r - 1), 1); b <- sample(2:(r - 1), 1)
  A <- ec_mul(a, G, cv); B <- ec_mul(b, G, cv)
  ec_equal(ec_mul(a, B, cv), ec_mul(b, A, cv))
}, logical(1))
cat("Key agreements tested:", n_pairs, " failures:", sum(!agree), "\n")

alice <- sample(2:(r - 1), 1); bob <- sample(2:(r - 1), 1)
A <- ec_mul(alice, G, cv); B <- ec_mul(bob, G, cv)
secret <- ec_mul(alice, B, cv)
attack <- bsgs(G, A, r, cv)                       # eavesdropper sees only A, B, G
recovered <- ec_mul(attack$k, B, cv)
cat("Attacker recovered Alice's private key:", attack$k == alice,
    "| recovered shared secret matches:", ec_equal(recovered, secret),
    "| steps:", attack$steps, "of", r, "possible keys\n")

saveRDS(list(axioms = axioms, group_order_23 = N, lagrange = lagrange, hasse = hasse,
             trace_ratio_97 = trace_ratio_97, scaling = scaling,
             ecdh_tested = n_pairs, ecdh_failures = sum(!agree),
             attack = list(recovered_key = attack$k == alice, secret_match = ec_equal(recovered, secret),
                           steps = attack$steps, r = r)),
        "data/clean/verification_results.rds")
